/**
* --------------------------------------------------------
 * 
 * Assignment 3
 * 
 * Written by: Min Dai (Student Id:2295244) 
 * 
 * For "Programming Concept 1" Section 05800- Winter 2022
 * 
 * --------------------------------------------------------
 * Question 1 - Part A
 * 
 * Purpose of this program : 
 *  
 * implement a class to set all the necessary instance  variables, constructors, and all the necessary methods
 */

import java.util.Scanner;
import java.text.DecimalFormat;
public class Property {
	
	// set instance variable
	private  String address;
	private int zoneCode;
	private int noOfBedrooms;
	private int yearOfConstruction;
	private float riskFactor;
	private int type;
	
	//set constant variable for different base_price
	private final int Base_Price1=300000;
	private final int Base_Price2=200000;
	private final int Base_Price3=100000;
	private final int Base_Price4=500000;
	private final int Base_Price5=400000;
	private final int Base_Price6=300000;
	
	public Property()//set the default constructor
	{
		address="";
		zoneCode=1;
		noOfBedrooms=0;
		yearOfConstruction=1900;
		riskFactor=0.0f;
		type=1;
	}
	
	public Property( int newType,String newAddress, int newZoneCode, int newNoOfBedrooms, 
			                 int newYearOfConstruction,  float newRiskFactor ) // set the customized constructor
	{
		address=newAddress;
		zoneCode=newZoneCode;
		noOfBedrooms=newNoOfBedrooms;
		yearOfConstruction=newYearOfConstruction;
		riskFactor=newRiskFactor;
		type=newType;
	}
	
	public Property( String newAddress,  int newNoOfBedrooms,    int newYearOfConstruction) // set the customized constructor
{
       address=newAddress;
       noOfBedrooms=newNoOfBedrooms;
       yearOfConstruction=newYearOfConstruction;
}
	
	public void setInfo()//ask user to input all the necessary information regarding their dwelling
	{
		Scanner input=new Scanner(System.in);
		System.out.println("Please enter the type of your house:(1 for condo, 2 for single family house");
		type=input.nextInt();
		input.nextLine();
		System.out.println("Please enter your address:");
		address=input.nextLine();
		System.out.println("Please enter the zone of your house:( 1 or 2 or 3 , no other number)");
		zoneCode=input.nextInt();
		System.out.println("Please enter the number of bedrooms you have");
		noOfBedrooms=input.nextInt();
		System.out.println("Please enter the construction year");
		yearOfConstruction=input.nextInt();
		System.out.println("Please enter the risk number related to investments in real estate market "
				                     + "(the number is a floating number between 0.0 to 1.0)");
		riskFactor=input.nextFloat();
	}
	
	public void setAddress(String address)//mutator method to set address
	{
		this.address=address;
	}
	
	public void setZoneCode(int zoneCode) //mutator method to set zone code
	{
		if(zoneCode==1||zoneCode==2||zoneCode==3)
			this.zoneCode=zoneCode;
		else
		{
			System.out.println("Invalid zone");
	        System.exit(0);
		}	
	}
	
	public void setNoOfBedrooms(int noOfBedrooms) //mutator method to set bedroom number
	{
		this.noOfBedrooms=noOfBedrooms;
	}
	
	public void setYearOfConstruction(int yearOfConstruction)//mutator method to set construction year
	{
		this.yearOfConstruction=yearOfConstruction;
	}
	
	public void setRiskFactor(float riskFactor) //mutator method to set risk factor
	{
		if(riskFactor>=0.0f&&riskFactor<=1.0)
			this.riskFactor=riskFactor;
		else
		{
			System.out.println("Fatal Error");
	        System.exit(0);
		}		
	}
			
	public void setType(int type)//mutator method to set type of dwelling
	{
		if(type==1||type==2)
			this.type=type;
		else
		{
			System.out.println(" Invalid type");
	        System.exit(0);
		}		
	}
	
	//to change the type of dwelling from integer to the String, so we know the number represent what kind of dwelling
	private String typeString(int typeNumber)
	{
		switch(typeNumber)
		{
		case 1:
			return "Condo";
		case 2:
			return "Single-family home";
		default:
			System.out.println("Invalid type");
	        System.exit(0);
			return "Error";
		 }	
	}
		
	public String getAddress() //Accessor method to get address
	{
		return address;
	}

	public int getZoneCode() //Accessor method to get zone code
	{
		if(zoneCode==1)
			return 1;
		else if(zoneCode==2)
			return 2;
		else if(zoneCode==3)
			return 3;
		else
		{
			System.out.println("Invalid zone");
	        System.exit(0);
	        return 0;
		}		
	}
	
	public int getNoOfBedrooms() //Accessor method to get bedroom number
	{
		return noOfBedrooms;
	}
	
	public int getYearOfConstruction() 
	{
		return  yearOfConstruction;
	}
	
	public float getRiskFactor() //Accessor method to get risk factor
	{
		if(riskFactor>=0.0f&&riskFactor<=1.0)
			return riskFactor;
		else
		{
			System.out.println("Fatal Error");
	        System.exit(0);
	     	return  0;
		}
	}
	
	public int getType() //Accessor method to get type of dwelling
	{
		if(type==1||type==2)
			return type;
		else
		{
			System.out.println("Invalid type");
	        System.exit(0);
	        return 0;
		}		
	}
	
	// accessor method to get the string type of dwelling , so we know the number represent what kind of dwelling
	private String getTypeString()
	{
		if(type==1)
			return "Condo";
		else if(type==2)
			return "Single-family Home";
		else
		{
			System.out.println("Invalid type");
	        System.exit(0);
			return "Error";
		}		
	}
	
	private double analyzeInvestment()//method to compute the value for property investment analysis
	{
		return riskFactor*50.0;	
	}
	
	// method to calculate the property price based on zone and type of property
	private double evaluatePrice(int type, int zoneCode)
	{
		double evaluatedPrice;
		if( type==1&&zoneCode==1)
		{
			 evaluatedPrice=Base_Price1+(0.05*Base_Price1*noOfBedrooms)+(yearOfConstruction*100)/2;
		     return evaluatedPrice;
		}
		else if( type==1&&zoneCode==2)
		{
			  evaluatedPrice=Base_Price2+(0.05*Base_Price2*noOfBedrooms)+(yearOfConstruction*100)/2;	
			  return evaluatedPrice;
		}
		else if( type==1&&zoneCode==3)
		{
			 evaluatedPrice=Base_Price3+(0.05*Base_Price3*noOfBedrooms)+(yearOfConstruction*100)/2;
			 return evaluatedPrice;
		}
		else if( type==2&&zoneCode==1)
		{
			 evaluatedPrice=Base_Price4+(0.05*Base_Price4*noOfBedrooms)+(yearOfConstruction*100)/2;
			 return evaluatedPrice;
		}
		else if(type==2&&zoneCode==2)
		{
			 evaluatedPrice=Base_Price5+(0.05*Base_Price5*noOfBedrooms)+(yearOfConstruction*100)/2;
			 return evaluatedPrice;
		}
		else if(type==2&&zoneCode==3)
		{
			 evaluatedPrice=Base_Price6+(0.05*Base_Price6*noOfBedrooms)+(yearOfConstruction*100)/2;	
			 return evaluatedPrice;
		}
		else
		{
			System.out.println("Invalid information");
	        System.exit(0);
			return 0;
		}				
	}
	
	public String toString()//to return clear description and information of the object
	{
		return("Type: "+getTypeString()+"\nAddress: "+address+"\nZone: "+zoneCode+"\nNo. of Bedrooms: "+noOfBedrooms
				  +"\nYear of  Construction: "+yearOfConstruction+"\nR Factor: "+riskFactor+ 
				  "\n\nInvestment analysis: "+numberFormat()+"\nEvaluated Price: $"+evaluatePrice(type, zoneCode));
	} 
	
	public boolean equals(Property other)//to compare if different project has the same value
	{
		return( address.equals(other.address)&&zoneCode==other.zoneCode&&noOfBedrooms==other.noOfBedrooms&&
				yearOfConstruction==other.yearOfConstruction&&riskFactor==other.riskFactor&&type==other.type);
	}
	
	private String  numberFormat()//to set the double to desired decimal format
	{
		DecimalFormat number=new DecimalFormat("0.0");
		double investmentAnalyze=analyzeInvestment();
		return (number.format(investmentAnalyze));
	}
	
}
