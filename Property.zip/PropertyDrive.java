/**
* --------------------------------------------------------
 * 
 * Assignment 3
 * 
 * Written by: Min Dai (Student Id:2295244) 
 * 
 * For "Programming Concept 1" Section 05800- Winter 2022
 * 
 * --------------------------------------------------------
 * Question 1 - Part B
 * 
 * Purpose of this program : 
 *  
 *  Write a driver program to test my class and to run the program
 */

import java.util.Scanner;
public class PropertyDrive {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//set 4 different  class object
		Property property1=new Property();
		Property property2=new Property(1,"20 Square St.",2,1,2020,0.02f);
		Property property3=new Property("65 rue College",3,1988);
		Property property4=new Property();
		
		//welcome information
		Scanner input=new Scanner(System.in);
		System.out.println("*****************************");
		System.out.println("Welcome to ABC Analyzer");
		System.out.println("*****************************");
		
		//use the class object and methods to set the related  information and display the related information for property 1
		System.out.println();
		System.out.println("Property 1:");
		property1.setType(1);
		property1.setAddress("7 Main St.");
		property1.setZoneCode(1);
		property1.setNoOfBedrooms(2);
		property1.setYearOfConstruction(2012);
		property1.setRiskFactor(0.1f);
		System.out.println(property1);
		
		//use the class object and methods to set the related  information and display the related information for property 2
		System.out.println();
		 System.out.println("==================");         
		System.out.println("Property 2:");
		System.out.println(property2);
		
		//use the class object and methods to set the related  information and display the related information for property 3
		System.out.println();
		 System.out.println("==================");          
		System.out.println("Property 3:");
		property3.setType(2);
		property3.setZoneCode(3);
		property3.setRiskFactor(0.2f);
		System.out.println(property3);
		
		//use the class object and methods to set the related  information and display the related information for property 4
		System.out.println();
		 System.out.println("==================");           
		System.out.println("Property 4:");
		property4.setInfo();
		System.out.println(property4);
		
		//a closing message so that the user knows that the program has terminated.
		System.out.println();
	    System.out.println("==================");      
		System.out.println("Thanks for using our software!");
		
	/*	if(property1.equals(property2))//to check if two property are same
			System.out.println("They are same");
		else
			System.out.println("They are not same");*/
		
		input.close();//close the keyboard
		
		
		
	}

}
